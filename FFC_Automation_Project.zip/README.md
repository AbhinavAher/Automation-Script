# FFC Automation Assignment

This project automates:

1. Login Journey (parameterized)
2. Punch-In Toast Validation
3. Add Customer (parameterized)

## How to Run

```
mvn clean test
```

## Tools Used
- Selenium 4
- TestNG
- Maven
- Java
- WebDriverManager
